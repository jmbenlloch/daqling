import os

from flask import Flask

def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY='dev', # SECRET_KEY to be changed for deployement
    )
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # Register blueprints
    from . import input
    app.register_blueprint(input.bp)

    from . import initPage
    app.register_blueprint(initPage.bp)
    app.add_url_rule("/", endpoint="menu")

    return app
