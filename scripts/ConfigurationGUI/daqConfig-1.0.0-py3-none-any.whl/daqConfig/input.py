import functools
import json
import os
from flask import (
    Blueprint, flash, render_template, request, url_for, current_app, redirect
)


bp = Blueprint('input',__name__)

@bp.route('/editModule',methods=('GET','POST'))
def editModule():
    if request.method == 'POST':
        # Saves the json file either internally to work on it or externally on the directory given by DAQ_CONFIGS_DIR
        if request.args.get('type') == "outFile": # External save
            data = request.data
            DAQ_CONFIGS_DIR = os.environ.get("DAQ_CONFIGS_DIR")
            fileName = DAQ_CONFIGS_DIR+'/'+request.args.get('currentFileName')
            with open(fileName,'w') as f:
                f.write(data.decode("utf-8"))
        elif request.args.get('type') == "tempFile": # Internal save
            data = request.data
            path_dummy = current_app.root_path + url_for('static',filename='json/dummyFile.json')
            with open(path_dummy,'w') as f:
                f.write(data.decode("utf-8"))
        elif request.args.get("type") == "selectSchema": # Change selected schema
            path_schema = current_app.root_path + url_for('static',filename='schema/config-schema.json')
            DAQ_CONFIGS_DIR = os.environ.get("DAQ_CONFIGS_DIR")
            currentSchemaName = request.args.get("schema")
            print(currentSchemaName)
            with open(DAQ_CONFIGS_DIR+"/schema/"+currentSchemaName,'r') as schema,open(path_schema,'w') as internalSchema:
                internalSchema.write(schema.read())

    return render_template('/editModule.html',currentFileName=request.args.get('currentFileName'))
